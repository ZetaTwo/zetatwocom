from z3 import *

s = Solver()

# Serial is 13 digits
serial = [BitVec('c%d' % i, 32) for i in range(13)]
for c in serial:
	s.add(c >= 0)
	s.add(c < 10)

# Partial sum
partials = [3]
for i in range(len(serial)-1):
	p = BitVec('p%d' % i, 32)
	s.add(p == partials[-1] + ((2*partials[-1]) ^ (serial[i])))
	partials.append(p)

# Final check
s.add(serial[-1] == (partials[-1] % 10))

# Print model
if s.check() == sat:
	m = s.model()
	res = map(lambda s: m[s].as_long(), serial)
	res = map(lambda n: chr(n+ord('0')), res)
	print(''.join(res))
