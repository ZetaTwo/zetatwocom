#!/usr/bin/env python
import angr
import claripy

"""
> file INSTALL.EXE 
INSTALL.EXE: PE32 executable (GUI) Intel 80386, for MS Windows
> sha256sum INSTALL.EXE
ba155a30ca11a57a2ea917cb4f25715f79bee7397ebb16db4816e7725395e58d  INSTALL.EXE
"""

ADDR_VALIDATE = 0x0040F8A0
ADDR_VALIDATE_OK = 0x0040F93F
ADDR_VALIDATE_BAD = [
    0x0040F8B5,
    0x0040F8DD,
    0x0040F937,
    0x0040F95B,
]

ADDR_RESOURCE_STRING = 0x00402DD0
ADDR_SET_ERROR = 0x0041696A

# This takes a long time
loader = angr.cle.Loader("INSTALL.EXE", auto_load_libs=False, use_system_libs=False)
print('Binary loaded')

proj = angr.Project(loader)

# Skip irrelevant functions
stub_func = angr.SIM_PROCEDURES['stubs']['ReturnUnconstrained']
proj.hook(ADDR_RESOURCE_STRING, stub_func())
proj.hook(ADDR_SET_ERROR, stub_func())

# Setup the symbolic input
serial_size = 32
sym_serial = claripy.BVS("sym_serial", serial_size * 8)

# HWND pointer can be NULL as all uses are hooked
state = proj.factory.call_state(ADDR_VALIDATE, sym_serial, 0)
simgr = proj.factory.simulation_manager(state)
simgr.explore(find=ADDR_VALIDATE_OK, avoid=ADDR_VALIDATE_BAD)

found = simgr.found[0] # A state that reached the find condition from explore
val_serial = found.solver.eval(sym_serial, cast_to=str) # Return a concrete string value for the sym arg to reach this state
val_serial = val_serial.strip('\x00') # Cleanup

print('Serial key: %s' % val_serial)
