#include <stdio.h>
#include <string.h>

// Compile with "gcc -o validator sc_serial_validate_clean.c"

int validate_serial(char *serial, size_t len)
{
  int result;
  unsigned int sum = 3;
  unsigned int i = 0;
  char current;

  if ( len == 13 )
  {
    do
    {
      current = serial[i];
      if ( current < '0' || current > '9' )
      {
        return 0;
      }
      sum += 2 * sum ^ (current - '0');
      ++i;
    }
    while ( i < 12 );
    if ( serial[12] == sum % 10 + '0' )
    {
      return 1;
    }
    else
    {
      return 0;
    }
  }
  else
  {
    return 0;
  }
}

int main(int argc, char **argv) {
  char serial[1024];
  scanf("%s", serial);
  printf("Serial: %s\nValid: %d\n", serial, validate_serial(serial, strlen(serial)));

  return 0;
}
