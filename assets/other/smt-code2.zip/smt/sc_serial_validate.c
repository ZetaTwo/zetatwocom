int __cdecl validate_serial(LPCSTR serial, HWND hWnd)
{
  int result; // eax@2
  unsigned int v3; // eax@5
  unsigned int v4; // edx@5
  CHAR v5; // cl@6

  if ( serial )
  {
    if ( lstrlenA(serial) == 13 )
    {
      v3 = 3;
      v4 = 0;
      do
      {
        v5 = serial[v4];
        if ( v5 < '0' || v5 > '9' )
        {
          LoadResourceString3(600, 601, hWnd);
          return 0;
        }
        v3 += 2 * v3 ^ (v5 - '0');
        ++v4;
      }
      while ( v4 < 12 );
      if ( serial[12] == v3 % 10 + '0' )
      {
        result = 1;
      }
      else
      {
        LoadResourceString3(600, 601, hWnd);
        result = 0;
      }
    }
    else
    {
      LoadResourceString3(600, 602, hWnd);
      result = 0;
    }
  }
  else
  {
    sub_41A4D9(0x57u);
    result = 0;
  }
  return result;
}
