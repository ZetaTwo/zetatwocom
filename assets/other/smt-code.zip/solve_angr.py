#!/usr/bin/python

import angr

def main():
    p = angr.Project('./validator2', load_options={"auto_load_libs": False})
    pg = p.factory.path_group()

    pg.explore(find=(0x4006d7,), avoid=(0x400683,0x4006de,0x4006e5,))

    found = pg.found[0]
    return found.state.posix.dumps(0).split('\0')[0]

if __name__ == '__main__':
    print(main())
